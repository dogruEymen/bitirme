/*
  # Academic Paper Clusters & Analytics Schema

  1. New Tables
    - `clusters`
      - `id` (uuid, primary key) - Unique cluster identifier
      - `name` (text) - Cluster display name (e.g., "Natural Language Processing")
      - `keyword` (text) - Primary keyword for image matching
      - `description` (text) - Short description of the cluster topic
      - `color` (text) - Hex color for chart/visual representation
      - `paper_count` (integer) - Number of papers in this cluster
      - `created_at` (timestamptz) - Creation timestamp

    - `papers`
      - `id` (uuid, primary key) - Unique paper identifier
      - `cluster_id` (uuid, foreign key) - Reference to cluster
      - `title` (text) - Paper title
      - `reference` (text) - Citation reference (e.g., "Smith et al., 2024, Nature")
      - `abstract` (text) - Paper abstract/summary
      - `is_representative` (boolean) - Whether this is a top representative paper for its cluster
      - `representation_score` (float) - How well this paper represents its cluster (0-1)
      - `published_at` (date) - Publication date
      - `is_weekly_pick` (boolean) - Whether this paper was selected as a weekly highlight
      - `week_label` (text) - Which week this belongs to (e.g., "2024-W01")
      - `created_at` (timestamptz) - Creation timestamp

    - `chat_messages`
      - `id` (uuid, primary key) - Unique message identifier
      - `user_id` (uuid) - User reference
      - `role` (text) - "user" or "assistant"
      - `content` (text) - Message content
      - `created_at` (timestamptz) - Message timestamp

  2. Security
    - Enable RLS on all tables
    - Clusters and papers are publicly readable (no auth required for reading)
    - Chat messages require authentication for read/write
    - Only authenticated users can insert/update their own chat messages
*/

-- Clusters table
CREATE TABLE IF NOT EXISTS clusters (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  keyword text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  color text NOT NULL DEFAULT '#3B82F6',
  paper_count integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE clusters ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Clusters are publicly readable"
  ON clusters FOR SELECT
  TO anon, authenticated
  USING (true);

-- Papers table
CREATE TABLE IF NOT EXISTS papers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cluster_id uuid NOT NULL REFERENCES clusters(id) ON DELETE CASCADE,
  title text NOT NULL,
  reference text NOT NULL DEFAULT '',
  abstract text NOT NULL DEFAULT '',
  is_representative boolean NOT NULL DEFAULT false,
  representation_score float NOT NULL DEFAULT 0,
  published_at date,
  is_weekly_pick boolean NOT NULL DEFAULT false,
  week_label text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE papers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Papers are publicly readable"
  ON papers FOR SELECT
  TO anon, authenticated
  USING (true);

-- Chat messages table
CREATE TABLE IF NOT EXISTS chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  role text NOT NULL CHECK (role IN ('user', 'assistant')),
  content text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own messages"
  ON chat_messages FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own messages"
  ON chat_messages FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_papers_cluster_id ON papers(cluster_id);
CREATE INDEX IF NOT EXISTS idx_papers_representative ON papers(is_representative) WHERE is_representative = true;
CREATE INDEX IF NOT EXISTS idx_papers_weekly_pick ON papers(is_weekly_pick) WHERE is_weekly_pick = true;
CREATE INDEX IF NOT EXISTS idx_chat_messages_user_id ON chat_messages(user_id);
